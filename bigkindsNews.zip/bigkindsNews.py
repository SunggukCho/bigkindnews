from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import NoSuchElementException
from pylab import plot, show
from selenium.webdriver.common.keys import Keys
import time

# 상세검색 - 기간설정 -키워드 인풋
driver = webdriver.Chrome()
url = 'https://www.kinds.or.kr/'
driver.get(url)
time.sleep(4)
##키워드 input
###여러가지 키워드가 동시에 등장하는 신문을 검색하고 싶으면 "문재인,이명박"과 같이 쉼표로 구분.
searchKeyword="문재인"
##상세검색 버튼 클릭.
driver.find_element_by_xpath('//*[@id="header"]/div[3]/div/div[3]/ul/li[1]/a').click()
time.sleep(1)
##기간설정 == 전체
fromDate="2017-08-01"
toDate="2017-08-15"

inputFromdate=driver.find_element_by_xpath('//*[@id="fromdate"]')
for i in range(0,10):
    inputFromdate.send_keys(Keys.BACKSPACE)
inputFromdate.send_keys(fromDate)
inputTodate=driver.find_element_by_xpath('//*[@id="todate"]')
for i in range(0,10):
    inputTodate.send_keys(Keys.BACKSPACE)
inputTodate.send_keys(toDate)

##중앙지
driver.find_element_by_xpath('//*[@id="chk_center"]').click()
time.sleep(1)
##경제지
driver.find_element_by_xpath('//*[@id="chk_eco"]').click()
time.sleep(1)
##지역종합지
driver.find_element_by_xpath('//*[@id="chk_local"]').click()
time.sleep(1)
##방송사
driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
# driver.find_element_by_xpath('//*[@id="chk_broadcast"]').click()
# time.sleep(1)

##검색 Enter!
inputKeyword = driver.find_element_by_xpath('//*[@id="searchDetailTxt1"]')
inputKeyword.send_keys(searchKeyword)
inputKeyword.send_keys(Keys.ENTER)
time.sleep(4)
#기사 데이터 수집
abc= driver.find_element_by_xpath('//*[@id="pop_newsTitle"]')
print(abc)
# //*[@id="pop_newsTitle"]
# //*[@id="pop_newsContent"]/div/div



# 타겟페이지 접속하기
#
#     tar_url = 'https://manage.searchad.naver.com/customers/1235077/tool/keyword-planner'
#     driver.get(tar_url)
#     time.sleep(2)
#     keybox = driver.find_element_by_xpath(
#         '//*[@id="wrap"]/div/div/div[1]/div[1]/div/div/div/div[2]/div[1]/div[1]/div[2]/form/div[1]/div/div/textarea')
#     keyword = '노트7'
#     keybox.send_keys(keyword)
#     driver.find_element_by_xpath(
#         '//*[@id="wrap"]/div/div/div[1]/div[1]/div/div/div/div[2]/div[1]/div[1]/div[2]/form/div[4]/div/div/ul/li/button').click()
#     time.sleep(2)
#     driver.find_element_by_class_name('keyword').click()
#     # 페이지에서 정보 긁어오기
#     time.sleep(2)
#     lines = driver.find_element_by_class_name('modal-open').find_element_by_class_name(
#         'highcharts-series-group').find_elements_by_class_name('highcharts-markers')
#     dates = driver.find_element_by_class_name('highcharts-axis-labels').text
#     datesList = dates.split('\n')
#     dotList = []
#     fw = open('naverAdresult2.txt', 'w', -1, 'UTF-8')
#
#     for line in lines:
#         time.sleep(2)
#         fw.write('\n')
#         point = line.find_elements_by_tag_name('path')
#         time.sleep(1)
#         hover = ActionChains(driver).move_to_element(point[0])
#         hover.perform()
#         for po in point:
#             hover = ActionChains(driver).move_to_element(po)
#             hover.perform()
#             dot = po.find_element_by_xpath('//*[@id="highcharts-0"]/div/span/div/table/tbody/tr/td[2]/strong').text
#             dotList.append(dot)
#     dotList.reverse()
#     list2 = []
#     for i in range(0, 12):
#         list2.append([datesList[i], dotList[i], dotList[i + 12]])
#
#     for inlist in list2:
#         fw.write('\t'.join(inlist))
#         fw.write('\n')
#
#     fw.close()
driver.close()